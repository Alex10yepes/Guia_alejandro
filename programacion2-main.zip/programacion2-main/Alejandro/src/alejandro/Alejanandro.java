/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gui_jeick777;

import FORMULARIO.FORMULARIO;

/**
 *
 * @author Biblioteca
 */
public class GUI_JEICK777 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       FORMULARIO f= new FORMULARIO();
       
       f.setVisible(true);
    }
    
}
